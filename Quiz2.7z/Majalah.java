/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author izul
 */
public class Majalah extends MediaInformasi {

    public void setJmlHalaman(int jmlHalaman) {
        this.jmlHalaman = jmlHalaman;
    }

    @Override
    public void reputasi() {
        System.out.println("Majalah Ini Memiliki: " + this.jmlHalaman + " Halaman");
        System.out.println("Jika dihitung dengan covernya, maka jumlah halaman dari majalaah tersebut: " + (this.jmlHalaman + 2) + " Halaman");
        System.out.println("Penerbit Majalah ini bereputasi!");
    }

}
