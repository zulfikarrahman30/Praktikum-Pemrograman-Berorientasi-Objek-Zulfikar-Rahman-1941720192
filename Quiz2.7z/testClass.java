/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author izul
 */
public class testClass {

    public static void Proses(MediaInformasi med) {
        if (med instanceof Majalah) {
            System.out.println("Majalah adalah media informasi!\n ");
        } else if (med instanceof Buku) {
            System.out.println("Buku adalah media informasi! \n");
        } else {
            System.out.println("Kategori Belum diketahui");
        }
    }

    public static void main(String[] args) {
        Majalah maj = new Majalah();
        Buku bk = new Buku();
        Proses(maj);
        Proses(bk);

        MediaInformasi medMaj = new Majalah();
        medMaj.setJmlHalaman(46);
        medMaj.reputasi();
        medMaj.alamatPenerbit("malang");
        int tahunSekarang = medMaj.getTahunSekarang(2020);
        medMaj.tahunBerdiri(1995);

        MediaInformasi medBk = new Buku();
        medBk.setJmlHalaman(340);
        medBk.reputasi();
        medBk.alamatPenerbit("Surabaya");
        medBk.getTahunSekarang(2030);
        medBk.tahunBerdiri(1978);
    }
}
