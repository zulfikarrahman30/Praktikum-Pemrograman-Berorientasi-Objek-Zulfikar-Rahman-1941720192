/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class RunObject {

    public static void main(String[] args) {
        Buku bk = new Buku();
        BukuGambar gambar = new BukuGambar();
        BukuTulis tulis = new BukuTulis();
        GelasPlastik Gp = new GelasPlastik();
        KipasAngin Kp = new KipasAngin();

        //Gelas PLastik
        System.out.println("gelas plastik");
        Gp.setWarna("Merah");
        Gp.tambahDiamterPlastik(8);
        Gp.tambahPanjangGangang(2);
        Gp.cetakStatus();

        //Kipas Angin
        System.out.println("kipas angin");
        Kp.setMerek("Cosmos");
        Kp.setWarna("Kuning");
        Kp.TambahKecepatan(5);
        Kp.KurangiKecepatan(2);
        Kp.cetakStatus();

        //Buku tulis
        System.out.println("buku tulis");
        tulis.setMerek("sinar mas");
        tulis.setTambahPanjang(5);
        tulis.setTambahLebar(2);
        tulis.setKurangiPanjang(2);
        tulis.setKurangiLebar(1);
        tulis.setBentuk("persegi panjang");
        tulis.TambahHalaman(5);
        tulis.KurangiHalaman(2);
        tulis.cetakStatus();

        //Buku Gambar
        System.out.println("buku gambar");
        gambar.setMerek("sinar mas");
        gambar.setTambahPanjang(5);
        gambar.setTambahLebar(2);
        gambar.setKurangiPanjang(2);
        gambar.setKurangiLebar(1);
        gambar.setKertas("a4");
        gambar.setKetebalan(2);
        gambar.cetakStatus();

    }
}
