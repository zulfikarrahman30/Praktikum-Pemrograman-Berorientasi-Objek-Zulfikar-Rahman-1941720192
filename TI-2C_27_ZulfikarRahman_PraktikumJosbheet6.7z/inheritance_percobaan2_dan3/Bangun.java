/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance_percobaan2_dan3;

/**
 *
 * @author izul
 */
public class Bangun {

    protected double phi;
    protected int r;
}
