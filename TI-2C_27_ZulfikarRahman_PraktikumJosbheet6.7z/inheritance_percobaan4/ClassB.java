/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance_percobaan4;

/**
 *
 * @author izul
 */
public class ClassB extends ClassA {

    ClassB() {
        System.out.println("konstruktor B dijalankan");
    }
}
