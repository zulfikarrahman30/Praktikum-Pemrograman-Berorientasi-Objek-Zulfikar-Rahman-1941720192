/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jawaban;

/**
 *
 * @author izul
 */
public class SepedaMotor extends Mesin{

     public Mesin mesin;
    public String merekSepeda;

    public SepedaMotor() {
    }
    
    public SepedaMotor(String merekSepeda, String merek) {
        super.merek = merekSepeda;
        this.merekSepeda = merek;
    }

    public void setMerekSepeda(String merek) {
        this.merekSepeda = merek;
    }

    public String getMerekSepeda() {
        return merekSepeda;
    }

    @Override
    public String getMerek() {
        return super.getMerek(); //
    }
    
    @Override
    public void tambahKecepatan(){
       super.tambahKecepatan();
    }

    @Override
    public void kurangiKecepatan() {
        super.kurangiKecepatan();
    }

}
