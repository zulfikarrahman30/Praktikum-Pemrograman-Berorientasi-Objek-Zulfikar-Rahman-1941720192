/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;



/**
 *
 * @author izul
 */
public class MainInheritance {

    public static void main(String[] args) {
        PC pc = new PC("ASUS TUF GAMING", 6, 8, "AMD Ryzen 5", 17);
        pc.tampilPc();

        Mac mac = new Mac("MacBook PRO", 4, 8, "Intel core i7", "Polimer", "Private internet access");
        mac.tampilMac();

        Windows windows = new Windows("ACER PREDATOR", 5, 8, "AMD Ryzen 7", "Acer Aspire Series 2920", "Ai");
        windows.tampilWindows();
    }
}
