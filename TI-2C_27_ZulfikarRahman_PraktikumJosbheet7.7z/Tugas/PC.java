/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

/**
 *
 * @author izul
 */
public class PC extends Komputer{

    public int ukuranMonitor;

    public PC() {

    }

    public PC(String merk, int kecProsesor, int Memory, String Prosesor, int ukuranMonitor) {
        super(merk, kecProsesor, Memory, Prosesor);
        this.ukuranMonitor = ukuranMonitor;
    }

    public void tampilPc() {
        System.out.println("=================PC=================");
        super.tampilData();
        System.out.println("Ukuran monitor      :" + ukuranMonitor);
    }
}
