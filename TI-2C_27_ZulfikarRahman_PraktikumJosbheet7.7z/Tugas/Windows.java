/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

/**
 *
 * @author izul
 */
public class Windows extends Laptop {

    public String fitur;

    public Windows() {

    }

    public Windows(String merk, int kecProsesor, int Memory, String Prosesor, String jnsBatrei, String fitur) {
        super(merk, kecProsesor, Memory, Prosesor, jnsBatrei);
        this.fitur = fitur;
    }

    public void tampilWindows() {
        System.out.println("=================LAPTOP WINDOWS=================");
        super.tampilLaptop();
        System.out.println("Fitur               : " + fitur);
    }
}
