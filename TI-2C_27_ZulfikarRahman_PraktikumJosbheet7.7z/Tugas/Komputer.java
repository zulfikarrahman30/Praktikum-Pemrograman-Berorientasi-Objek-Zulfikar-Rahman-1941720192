/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

/**
 *
 * @author izul
 */
public class Komputer {

    public String merk, Prosesor;
    public int kecProsesor, Memory;

    public Komputer() {

    }

    public Komputer(String merk, int kecProsesor, int sizeMemory, String jnsProsesor) {
        this.merk = merk;
        this.kecProsesor = kecProsesor;
        this.Memory = Memory;
        this.Prosesor = Prosesor;
    }

    public void tampilData() {
        System.out.println("Merk                : " + merk);
        System.out.println("Kecepatan Prosesor  : " + kecProsesor + " Ghz");
        System.out.println("Ukuran Memory       : " + Memory + " GB");
        System.out.println("Jenis prosesor      : " + Prosesor);
    }
}
