/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Percobaan1;

/**
 *
 * @author izul
 */
public class Inheritence1 {

    public static void main(String[] args) {
        Manager M = new Manager();
        M.nama = "Tony";
        M.alamat = "L.A Street";
        M.umur = 30;
        M.jk = "Male";
        M.gaji = 3000000;
        M.tunjangan = 1000000;
        M.tampilDataManager();

        Staff S = new Staff();
        S.nama = "Stark";
        S.alamat = "Miami Street";
        S.umur = 21;
        S.jk = "Male";
        S.gaji = 2000000;
        S.lembur = 500000;
        S.potongan = 250000;
        S.tampilDataStaff();
    }
}
