/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Percobaan1;

/**
 *
 * @author izul
 */
public class Inheritance1percobaan2 {

    public static void main(String[] args) {
        StaffTetap ST = new StaffTetap("Audi", "California Street", "Male", 20, 2000000, 250000, 200000, "2A", 100000);
        ST.tampilStaffTetap();

        StaffHarian SH = new StaffHarian("Naomi", "N.Y Street", "Female", 27, 10000, 100000, 50000, 100);
        SH.tampilStaffHarian();
    }
}
