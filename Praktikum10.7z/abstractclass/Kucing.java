/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractclass;

/**
 *
 * @author izul
 */
public class Kucing extends Hewan {

    @Override
    public void bergerak() {
        System.out.println("Berjalan dengan KAKI, \"Tap..Tap..\"");
    }
}
