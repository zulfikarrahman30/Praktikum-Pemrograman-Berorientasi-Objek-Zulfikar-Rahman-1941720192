/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

/**
 *
 * @author izul
 */
public class Singa extends Binatang implements Karnivora, Herbivora {

    public String suara;
    public String WarnaBulu;

    public void Singa(String nama, int jmlKaki, String suara, String warnaBulu) {
        this.Singa(nama, jmlKaki, suara, warnaBulu);
    }

    public void Binatang(String nama, int jmlKaki) {
        this.Binatang(nama, jmlKaki);
    }

    @Override
    public String nama() {
        System.out.println("Nama: Mufasa");
        return suara;
    }

    @Override
    public int jmlKaki() {
        System.out.println("Jumlah Kaki: 4 kaki");
        return 4;
    }

    @Override
    public void Makan() {
        System.out.println("Makanan: Daging");
    }

    void WarnaBulu() {
        System.out.println("Warna Bulu: Krem");
    }

    void Suara() {
        System.out.println("Suara: Mbeeeek");
    }

    void Jenis() {
        System.out.println("Jenis: Karnivora");
    }
}
