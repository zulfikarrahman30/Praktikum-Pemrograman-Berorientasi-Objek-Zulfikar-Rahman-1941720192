/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

/**
 *
 * @author izul
 */
public class Gorila extends Binatang implements Karnivora, Herbivora {

    public String suara;
    public String WarnaBulu;

    public void Gorilla(String nama, int jmlKaki, String suara, String warnaBulu) {
        this.Gorilla(nama, jmlKaki, suara, warnaBulu);
    }

    public void Binatang(String nama, int jmlKaki) {
        this.Binatang(nama, jmlKaki);
    }

    @Override
    public String nama() {
        System.out.println("Namanya: Ape");
        return suara;
    }

    @Override
    public int jmlKaki() {
        System.out.println("Jumlah Kaki: 4 kaki");
        return 4;
    }

    @Override
    public void Makan() {
        System.out.println("Makanan: Daging + Tumbuhan");
    }

    void WarnaBulu() {
        System.out.println("Warna Bulu: Hitam Abu-Abu");
    }

    void Suara() {
        System.out.println("Suara: u u a a ");
    }

    void Jenis() {
        System.out.println("Jenis: Karnivora + Herbivora");
    }

}
