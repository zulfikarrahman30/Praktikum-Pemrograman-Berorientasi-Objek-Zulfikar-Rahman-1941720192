/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

/**
 *
 * @author izul
 */
public class Keledai extends Binatang implements Karnivora, Herbivora {

    public String suara;
    public String WarnaBulu;

    public void Keledai(String nama, int jmlKaki, String suara, String warnaBulu) {
        this.Keledai(nama, jmlKaki, suara, warnaBulu);
    }

    public void Binatang(String nama, int jmlKaki) {
        this.Binatang(nama, jmlKaki);
    }

    @Override
    public String nama() {
        System.out.println("Namanya: Donkey");
        return suara;
    }

    @Override
    public int jmlKaki() {
        System.out.println("Jumlah Kaki: 4 kaki");
        return 4;
    }

    @Override
    public void Makan() {
        System.out.println("Makanan: Tumbuhan");
    }

    void WarnaBulu() {
        System.out.println("Warna Bulu: Putih");
    }

    void Suara() {
        System.out.println("Suara: Meong");
    }

    void Jenis() {
        System.out.println("Jenis: Herbivora");
    }
}
