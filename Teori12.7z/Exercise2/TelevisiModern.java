/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercise2;

/**
 *
 * @author izul
 */
public class TelevisiModern extends Elektronik {

    private String modelInput;

    public TelevisiModern(String modelInput, int voltase) {
        super(voltase);
        this.modelInput = modelInput;
    }

    public String getModelInput() {
        return modelInput;
    }
}
