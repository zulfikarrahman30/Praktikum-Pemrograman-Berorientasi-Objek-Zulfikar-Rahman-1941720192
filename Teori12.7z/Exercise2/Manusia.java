/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercise2;

/**
 *
 * @author izul
 */
public class Manusia {
    public void nyalakanPerangkat(Elektronik perangkat){
        int daya = perangkat.getVoltase();
        
        if(perangkat instanceof TelevisiJadul){
            System.out.println("Nyalakan televisi jadul dengan input: " + ((TelevisiJadul) perangkat).getModelInput());
            daya = 200;
            System.out.println("Voltase televisi: " + daya);
        }
        else if(perangkat instanceof TelevisiModern){
            System.out.println("Nyalakan televisi jadul dengan unput: " + ((TelevisiModern) perangkat).getModelInput());
            daya = 200;
            System.out.println("Voltase televisi: " + daya);
        }
        else{
            System.out.println("Salah input");
        }
    }
}
