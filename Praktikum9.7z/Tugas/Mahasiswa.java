/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

/**
 *
 * @author izul
 */
public class Mahasiswa extends Manusia {

    public void bernafas() {
        System.out.println("Mahasiswa dapat bernafas");
    }

    public void makan() {
        System.out.println("Mahasiswa juga dapat makan");
    }
}
