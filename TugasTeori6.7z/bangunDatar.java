/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasTeori;

/**
 *
 * @author izul
 */
public class bangunDatar {

    public float luas(float p, float l, float r, float a, float t) {
        float luas;
        System.out.println("Menghitung Luas Bangun Datar");
        System.out.println("Lingkaran ");
        System.out.println(luas = (float) (3.14 * r * r));
        System.out.println("Persegi Panjang");
        System.out.println(luas = p * l);
        System.out.println("Segitiga");
        System.out.println(luas = (float) (0.5 * a * t));
        return luas;
    }

    public float keliling(float p, float l, float r) {
        float keliling;
        System.out.println("Menghitung Keliling Bangun Datar");
        System.out.println("Lingkaran");
        System.out.println(keliling = (float) (2 * 3.14 * r));
        System.out.println("Persegi Panjang");
        System.out.println(keliling = 2 * (p + l));
        return keliling;
    }

}
