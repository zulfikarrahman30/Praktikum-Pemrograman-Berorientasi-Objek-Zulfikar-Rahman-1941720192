/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasTeori;

/**
 *
 * @author izul
 */
public class persegiPanjang extends bangunDatar {
    public float panjang;
    public float lebar;
}
