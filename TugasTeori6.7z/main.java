/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasTeori;

/**
 *
 * @author izul
 */
public class main {
 public static void main(String[] args){
        Lingkaran l = new Lingkaran();
        persegiPanjang p = new persegiPanjang();
        bangunDatar b = new bangunDatar();
        Segitiga s = new Segitiga();
        
        l.r = 6;
        p.lebar = 6;
        p.panjang = 9;
        s.alas = 14;
        s.tinggi = 7;
        
        
        b.keliling(p.panjang, p.lebar, l.r);
        b.luas(p.panjang, p.lebar, l.r,s.tinggi,s.alas);
        
        
    }
   
}
