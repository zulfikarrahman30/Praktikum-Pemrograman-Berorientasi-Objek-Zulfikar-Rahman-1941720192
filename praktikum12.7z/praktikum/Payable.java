
package praktikum;

public interface Payable {
    public int getPaymentAmount();
}
